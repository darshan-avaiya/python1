"""
Decorators are used to decorate the functions, generally it is used on top of the function

Decorators is used when we want add some extra functionality to existing function,
without touching existing function, we just use decorators to turn on and off the newly added code..
"""


# ---------------simple Way--------------
def first_function(func_name):
    print("This is first function")
    return func_name


def second_function():
    print("This is second function")


temp = first_function(second_function)
temp()

# ---------------On the decorator way---------------------------

"""
second_function() will be passed in first_function in below condition
"""


def first_function(func_name):
    print("\nBefore function call")
    func_name()
    print("After function call")


@first_function
def second_function():
    print("This is second function")
# ------------------------------------------
