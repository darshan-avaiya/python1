# define function
def greeting():
    print("Hello world")


# call function
greeting()

"""---------------------------------------"""


def enter_name(name):
    print(f"Hello {name}")


enter_name("Darshan")

"""---------------------------------------"""


def enter_name(name="Test"):
    print(f"Hello {name}")


enter_name()
enter_name("Darshan")

"""---------------------------------------"""


def add(num1, num2):
    return num1 + num2


result = add(10, 20)
assert result == 30

"""---------------------------------------"""
def addition(*args):
    print(args[0])


addition(10, 20)

"""---------------------------------------"""
