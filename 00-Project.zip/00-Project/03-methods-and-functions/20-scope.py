# global variable
num = 10


def func1():
    # local variable which is accessible only within the defined function
    num = 20

    def inner():
        assert num == 20

    inner()


def func2():
    # change value of global variable
    global num
    num = 20


assert num == 10
func1()
assert num == 10

assert num == 10
func2()
assert num == 20
