def check_number(num):
    if num % 2 == 0:
        print("Even")
    else:
        print("Odd")


check_number(20)
check_number(21)

"""---------------------------------------"""


# Return True if any of the number is "even" type inside the given list
def check_even(num_list):
    for num in num_list:
        if num % 2 == 0:
            return True
        else:
            pass
    return False


assert check_even([1, 3, 2]) == True
assert check_even([1, 3, 5]) == False

"""---------------------------------------"""


# Return all the "even" number in a list
def check_even(num_list):
    temp = []
    for num in num_list:
        if num % 2 == 0:
            temp.append(num)
        else:
            pass
    return temp


assert check_even([1, 2, 3, 4, 5]) == [2, 4]
assert check_even([1, 3, 5]) == []

"""---------------------------------------"""
