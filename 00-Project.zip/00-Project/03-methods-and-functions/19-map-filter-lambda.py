list1 = [1, 2, 3, 4, 5]

"""--------------------Map Function--------------------------------"""


def square(num):
    return num ** 2


assert list(map(square, list1)) == [1, 4, 9, 16, 25]

"""-------------------Filter Function-------------------------------"""


def even(num):
    return num % 2 == 0


assert list(filter(even, list1)) == [2, 4]

"""-------------------Lambda Function--------------------------------"""

sqr = lambda num: num ** 2

assert sqr(10) == 100

"""-----------Combination of Map, Filer, Lambda Function-------------"""

assert list(map(lambda num: num ** 2, list1)) == [1, 4, 9, 16, 25]
assert list(filter(lambda num: num % 2 == 0, list1)) == [2, 4]
assert list(map(lambda X: X[::-1], ["Darshan", "ABCD", "TEMP"])) == ["nahsraD", "DCBA", "PMET"]
assert list(map(lambda X: X[0], ["Darshan", "ABCD", "TEMP"])) == ["D", "A", "T"]
