def myfunc(*args):
    return args


assert myfunc(10, 20, 30, "Darshan") == (10, 20, 30, "Darshan")

"""----------------------------------------------------"""


def myfunc(**kwargs):
    return kwargs


assert myfunc(num1=10, num2=20, num3=30, name4="Darshan") == {"num1": 10, "num2": 20, "num3": 30, "name4": "Darshan"}
assert list(myfunc(num1=10, num2=20, num3=30, name4="Darshan").items()) == [("num1", 10), ("num2", 20), ("num3", 30), ("name4", "Darshan")]

"""----------------------------------------------------"""


def myfunc(*args):
    temp = 0
    for arg in args:
        if isinstance(arg, int) or (isinstance(arg, str) and arg.isnumeric()):
            temp += int(arg)
    return temp


assert myfunc(10, 20, 30, "10", "Darshan") == 70
