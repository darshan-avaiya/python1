num = int(input("Enter number: "))

if num <= 10:
    print("Entered number is less than 10")
elif 10 < num <= 20:
    print("Number is between 10 and 20")
else:
    print("Number is greater than 20")
