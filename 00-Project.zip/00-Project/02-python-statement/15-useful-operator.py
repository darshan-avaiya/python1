# 1 range()
assert list(range(5)) == [0, 1, 2, 3, 4]
assert list(range(3, 10)) == [3, 4, 5, 6, 7, 8, 9]
assert list(range(3, 10, 2)) == [3, 5, 7, 9]

list1 = []
for num in range(3, 10):
    list1.append(num)
assert list1 == [3, 4, 5, 6, 7, 8, 9]

# 2 enumerate()
assert list(enumerate(["Apple", "Banana", "Orange"])) == [(0, 'Apple'), (1, 'Banana'), (2, 'Orange')]

list2 = ["Apple", "Banana", "Orange"]
final_list = []
for item in enumerate(list2):
    final_list.append(item)
assert final_list == [(0, 'Apple'), (1, 'Banana'), (2, 'Orange')]

for index, letter in enumerate("Happy"):
    print(index, letter)

# 3 zip() - mapping object
list1 = [1, 2, 3, 4, 5]
list2 = ["Apple", "Banana", "Orange"]
assert list(zip(list1, list2)) == [(1, 'Apple'), (2, 'Banana'), (3, 'Orange')]

list3 = []
for item in zip(list1, list2):
    list3.append(item)
assert list3 == [(1, 'Apple'), (2, 'Banana'), (3, 'Orange')]

# 4 in
assert (3 in [1, 2, 3]) == True
assert ('a' in "Avaiya") == True
assert ("key1" in {"key1": "value1"}) == True
assert ("value1" in {"key1": "value1"}.values()) == True

# 5 min and max
assert min([150, 10, 50]) == 10
assert max([150, 10, 50]) == 150

# 6 random
import random

list1 = [1, 2, 3, 4, 5]
random.shuffle(list1)
print(list1)  # [5, 1, 4, 3, 2]

print(random.randint(10, 20))
