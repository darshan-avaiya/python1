num = 0

while (num < 10):
    num = num + 1

    # skip
    if num == 2:
        continue

    # exit from the loop
    if num == 8:
        break
    print("Number : ", num)
else:
    print("Loop exit : ", num)
