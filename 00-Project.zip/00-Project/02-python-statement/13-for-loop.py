items = ["Apple", "Banana", "Orange"]
for item in items:
    print(item)

items = ("Apple", "Banana", "Orange")
for item in items:
    print(item)

dict1 = {"key1": "value1", "key2": "value2", "key3": "value3"}
assert list(dict1.items()) == [('key1', 'value1'), ('key2', 'value2'), ('key3', 'value3')]
for item in dict1.items():
    print(item)

# unpacking tuple from dictionary
for (key, value) in dict1.items():
    print(key)
    print(value)
