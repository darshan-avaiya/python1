def enter_number():
    while True:
        number = input("Enter a number : ")

        if number.isdigit() == False:
            print("Entered input is not a digit")
            continue

        if number.isdigit() == True:
            if int(number) not in range(0, 10):
                print(f"Enter number {number} is not in the given range")
                continue
            else:
                print(f"You have entered valid input : {number}")
                break


enter_number()
