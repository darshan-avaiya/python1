list1 = [0, 1, 2]


def play_again():
    while True:
        play_choice = input("Do you want to play again - Y or N ? : ")
        if play_choice.lower() == 'y':
            return
        elif play_choice.lower() == 'n':
            exit(0)
        else:
            print("Please enter valid choice")
            continue


def play_game(list1):
    while True:
        position = input("Enter a position to be replaced (0,1,2) : ")

        if position.isdigit() == False or int(position) not in range(0, 3):
            print("Please enter valid input")
            continue
        else:
            value = input("Enter a string value to replace on the given position : ")
            list1[int(position)] = value
            print(f"New list is : {list1}")

        play_again()


play_game(list1)
