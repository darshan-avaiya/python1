# --------------------------------------------
from collections import Counter

list1 = ['a', 'a', 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4, 4, 4]
assert dict(Counter(list1)) == {'a': 2, 1: 4, 2: 6, 3: 3, 4: 4}

letters = 'aaaaaaaaaabbbbbbbbbbcccccccccccddddeee'

# Number of items with in key/value pair
assert dict(Counter(letters)) == {'a': 10, 'b': 10, 'c': 11, 'd': 4, 'e': 3}

# Most common items
assert Counter(letters).most_common() == [('c', 11), ('a', 10), ('b', 10), ('d', 4), ('e', 3)]

# 3 Most common items
assert Counter(letters).most_common(3) == [('c', 11), ('a', 10), ('b', 10)]

# --------------------------------------------

from collections import defaultdict

dict1 = defaultdict(lambda: "Not present")

dict1['a'] = 10
dict1['b'] = 20

assert dict1 == {'a': 10, 'b': 20}

print(dict1['test'])

assert dict1 == {'a': 10, 'b': 20, 'test':"Not present"}

# --------------------------------------------
