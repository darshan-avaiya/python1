import pdb
import random

# Returns a random number between the given range
num1 = random.randint(15, 75)
print(num1)

list1 = list(range(10, 20))
assert list1 == [10, 11, 12, 13, 14, 15, 16, 17, 18, 19]

# Returns a random element from the given sequence
c1 = random.choice(list1)
print(c1)

# Returns a list with a random selection from the given sequence (One element can be pick up multiple time)
c2 = random.choices(population=list1, k=5)
print(c2)

# Returns a given sample of a sequence (One element can not be pick up multiple times)
c3 = random.sample(population=list1, k=5)
print(c3)

# Returns a random float number between 0 and 1
# Example : 0.367699498292715
print(random.random())

# Returns a random float number between two given parameters
print(random.uniform(10, 100))

# Initialize the random number generator
random.seed(101)
assert random.randint(10, 100) == 84
assert random.randint(10, 100) == 34
assert random.randint(10, 100) == 79

# To debug the code
# pdb.set_trace()
