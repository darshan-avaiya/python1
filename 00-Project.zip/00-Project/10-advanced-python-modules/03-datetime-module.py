import datetime

# '_hour', '_minute', '_second', '_microsecond', '_tzinfo', '_hashcode', '_fold'
time1 = datetime.time(2, 20, 25, 123)
assert str(time1) == "02:20:25.000123"
assert time1.hour == 2
assert time1.minute == 20
assert time1.second == 25
assert time1.microsecond == 123

# '_year', '_month', '_day', '_hashcode'
date1 = datetime.date.today()
assert str(date1) == "2024-01-02"

date3 = datetime.date(1998, 7, 5)
assert str(date3) == "1998-07-05"
assert date3.year == 1998
assert date3.month == 7
assert date3.day == 5

assert date3.ctime() == "Sun Jul  5 00:00:00 1998"

# datetime
datetime1 = datetime.datetime(1998, 7, 5, 13, 45, 50, 123)
assert str(datetime1) == "1998-07-05 13:45:50.000123"

datetime1 = datetime1.replace(month=6, day=18)
assert str(datetime1) == "1998-06-18 13:45:50.000123"

# -------------------------------------
datetime1 = datetime.datetime(2024, 1, 2, 11, 58, 25, 123)
datetime2 = datetime.datetime(1998, 7, 5, 6, 50, 25, 123)
diff = datetime1 - datetime2
assert str(diff) == "9312 days, 5:08:00"
assert diff.days == 9312
assert diff.seconds == 18480  # only this part -> 5:08:00
assert diff.total_seconds() == 804575280
