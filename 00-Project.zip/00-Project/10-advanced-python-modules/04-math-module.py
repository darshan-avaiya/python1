import math

# Rounds a number down to the nearest integer
assert math.floor(4.35) == 4

# Rounds a number up to the nearest integer
assert math.ceil(4.35) == 5

# Returns the square root of a number
assert math.sqrt(16) == 4

# Returns the value of x to the power of y
assert math.pow(2, 5) == 32

# Returns the natural logarithm of a number, or the logarithm of number to base
assert round(math.log(1000, 10)) == 3
assert round(math.log(8, 2)) == 3

# Converts an angle from radians to degrees
assert math.degrees(math.pi/2) == 90

# Converts a degree value into radians
assert math.radians(90) == math.pi/2

# Math Constants
assert math.pi == 3.141592653589793
assert math.e == 2.718281828459045
assert str(math.nan) == "nan"
assert str(math.inf) == "inf"

"""
if the decimal 5 follows an odd digit, round to nearest number above. Example: 73.5 rounds to 74. 
if the decimal 5 follows an even digit, round to nearest number below. Example: 78.5 rounds to 78.
"""
assert round(4.35) == 4
assert round(5.35) == 5
assert round(73.5) == 74
assert round(74.5) == 74
assert round(4.5) == 4
assert round(5.5) == 6
