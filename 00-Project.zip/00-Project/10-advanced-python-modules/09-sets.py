"""
Sets : A set is a set of characters inside a pair of square brackets [] with a special meaning
"""


import re


# [arn] : Check if the string has any a, r, or n characters:
assert re.findall("[xz]","My name is Darshan") == []
assert re.findall("[arn]", "The rain in Spain") == ['r', 'a', 'n', 'n', 'a', 'n']

# [a-n] : Returns a match for any lower case character, alphabetically between a and n
assert re.findall("[a-n]","The rain in Spain") == ['h', 'e', 'a', 'i', 'n', 'i', 'n', 'a', 'i', 'n']

# [^arn] : Returns a match for any character EXCEPT a, r, and n
assert re.findall("[^arn]","The rain in Spain") == ['T', 'h', 'e', ' ', 'i', ' ', 'i', ' ', 'S', 'p', 'i']

# [0123] : Returns a match where any of the specified digits (0, 1, 2, or 3) are present
assert re.findall("[0123]","The rain 3 in Spain 1") == ["3","1"]

# [0-9] : Returns a match for any digit between 0 and 9
assert re.findall("[0-9]","This is 123 method 562") == ["1","2","3","5","6","2"]

# [0-5][0-9] : Returns a match for any two-digit numbers from 00 and 59
assert re.findall("[0-5][0-9]","9876543210") == ['54', '32', '10']

# [a-zA-Z] : Returns a match for any character alphabetically between a and z, lower case OR upper case
assert re.findall("[a-zA-Z]","8 times before 11:45 AM") == ['t', 'i', 'm', 'e', 's', 'b', 'e', 'f', 'o', 'r', 'e', 'A', 'M']

# [+] : In sets, +, *, ., |, (), $,{} has no special meaning, so [+] means: return a match for any + character in the string
assert re.findall("[+]","8 times before 11:45 + 05:30 AM") == ["+"]
