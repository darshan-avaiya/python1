# ------------------ Os module ------------
import os

# Get current working directory path
print(os.getcwd())

# Get list of all files and folders in working directory
print(os.listdir())

# Get list of all files and folders in the given directory
print(os.listdir("D:\\"))

# ------------------ Delete File/Folder ------------

# Deleting a file
# os.remove('file_path')

# Deleting an empty directory
# os.rmdir('directory_path')

# Deleting a non-empty directory - Most dangerous command
# import shutil
# shutil.rmtree('directory_path')

# ------------------ Move File/Folder ------------
# show utility command
import shutil

file = open("temp.txt", "w+")
file.write("Ths is a temp file")
file.close()

# Move to different location and remove the file
shutil.move("temp.txt", "D:\\2.Learning\\1.Python_learning\\0.udemy_training\\00-Project\\resources\\")
os.remove("D:\\2.Learning\\1.Python_learning\\0.udemy_training\\00-Project\\resources\\temp.txt")

# ------------------ Move files to trash ------------
# Install the send2trash library -- pip install send2trash

import send2trash

file = open("temp123.txt", "w+")
file.write("Ths is a temp file")
file.close()

send2trash.send2trash("temp123.txt")

# --------------------os.walk()----------------

for folders, sub_folders, files in os.walk(r"D:\\2.Learning\\1.Python_learning\\0.udemy_training\\00-Project"):

    print(f"\nCurrently looking at {folders} : ")

    for sub_folder in sub_folders:
        print(f"Sub Folder : {sub_folder} : ")

    for file in files:
        print(f"File : {file}")

# ------------------------------------------------
