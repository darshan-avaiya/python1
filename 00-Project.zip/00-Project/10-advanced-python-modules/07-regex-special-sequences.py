"""
Special Sequences : A special sequence is a \ followed by one of the characters in the list below, and has a special meaning
"""
import re

# ------------------------\d : digit-----------------------------

assert re.findall("\d", "The rain in Spain") == []
assert re.findall("\d", "9876543210") == ["9", "8", "7", "6", "5", "4", "3", "2", "1", "0"]
assert re.findall("\d", "There is 5 pen available on 3 tables and 651 books") == ["5", "3", "6", "5", "1"]
assert re.findall(r"\d\d\d-\d\d\d-\d\d\d\d",
                  "Phone numbers : (987)-123-4565, (977)-123-4565, 123-456-7890, 987-654-1230") == ["123-456-7890",
                                                                                                    "987-654-1230"]
assert re.findall(r"\(\d\d\d\)-\d\d\d-\d\d\d\d",
                  "Phone numbers : (987)-123-4565, (977)-123-4565, 123-456-7890, 987-654-1230") == ['(987)-123-4565',
                                                                                                    '(977)-123-4565']
assert re.findall(r"e_\d\d", "this is file_25, style_89") == ["e_25", "e_89"]

# ------------------------\D : non digit (string + special character + space)-----------------------------

assert re.findall("\D", "9876543210") == []
assert re.findall("\D", "The rain in Spain") == ['T', 'h', 'e', ' ', 'r', 'a', 'i', 'n', ' ', 'i', 'n', ' ', 'S', 'p',
                                                 'a', 'i', 'n']
assert re.findall("\D", "The rain in Spain A123 !@#") == ['T', 'h', 'e', ' ', 'r', 'a', 'i', 'n', ' ', 'i', 'n', ' ',
                                                          'S',
                                                          'p', 'a', 'i', 'n', ' ', 'A', ' ', "!", "@", "#"]
temp = re.findall("\D", "The rain in Spain A123")
assert ''.join(temp) == "The rain in Spain A"

# ------------------------\w : Alphanumeric (Includes _ [underscore] but no space, no special char)----------------
assert re.findall("\w", "!@#$%^&*()_+-=[]{}\|:;'<>?,./`~*-") == ['_']
assert re.findall("\w", "The rain in Spain A123!@#$") == ['T', 'h', 'e', 'r', 'a', 'i', 'n', 'i', 'n', 'S', 'p', 'a',
                                                          'i', 'n', 'A', '1', '2', '3']
assert re.findall(r"\w{7}", "My roll is 15EL069, 1234567, abcdefg") == ["15EL069", "1234567", "abcdefg"]
assert re.findall(r"\w\w", "My roll is 15EL069 1234567 abcdefg") == ['My', 'ro', 'll', 'is', '15', 'EL', '06', '12',
                                                                     '34', '56', 'ab', 'cd', 'ef']

# ------------------------\W : Non-Alphanumeric (Including space + special char)-----------------------------
assert re.findall("\W", "TheraininSpain") == []
assert re.findall("\W", "The rain in Spain A123!@#$") == [" ", " ", " ", " ", "!", "@", "#", "$"]
assert re.findall(r"\W{7}", "My roll is 15EL069 1234567 abcdefg") == []

# ------------------------\s : White space-----------------------------
assert re.findall("\s", "My name is Darshan") == [" ", " ", " "]

# ------------------------\S : Non-White space-----------------------------
assert re.findall("\S", "My name is Darshan") == ['M', 'y', 'n', 'a', 'm', 'e', 'i', 's', 'D', 'a', 'r', 's', 'h', 'a',
                                                  'n']
