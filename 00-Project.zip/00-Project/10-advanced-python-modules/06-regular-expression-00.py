"""
A RegEx (Regular Expression) is used to find-out a specific sequence of characters or pattern.
"""

import re

# ---------------------------------------------------------
string1 = "Phone number : (987)-123-4565, (977)-123-4565, 123-456-7890, 987-654-1230"

# Returns a list containing all matches
pattern1 = r"\(\d\d\d\)-\d\d\d-\d\d\d\d"
assert re.findall(pattern1, string1) == ['(987)-123-4565', '(977)-123-4565']

pattern2 = r"\d\d\d-\d\d\d-\d\d\d\d"
assert re.findall(pattern2,string1) == ["123-456-7890", "987-654-1230"]

pattern3 = r"\(\d{3}\)-\d{3}-\d{4}"
assert re.findall(pattern3, string1) == ['(987)-123-4565', '(977)-123-4565']

# Returns a Match object if there is a match anywhere in the string
pattern3 = r"\(\d{3}\)-\d{3}-\d{4}"
temp = re.search(pattern3, string1)
assert temp.span() == (15,29)
assert temp.group() == "(987)-123-4565"
assert temp.string == "Phone number : (987)-123-4565, (977)-123-4565, 123-456-7890, 987-654-1230"
# ---------------------------------------------------------
