"""
Metacharacters - Metacharacters are characters with a special meaning
"""

import re

# ------------------------[] : A set of characters----------------------
assert re.findall("[a-m]", "The rain in Spain") == ['h', 'e', 'a', 'i', 'i', 'a', 'i']

# ------------------------- . : Any character (except newline character)----------------------
assert re.findall("he..o", "hello planet") == ["hello"]

# ------------------------ ^ : Starts with -----------------------------
assert re.findall("^hel", "hello planet") == ["hel"]

# ------------------------ $ : Ends with -------------------------------
assert re.findall("net$", "hello planet") == ["net"]

"""
* : Zero or more occurrences
+ : One or more occurrences
? : Zero or one occurrences
"""
assert re.findall("he.*o", "hello planet") == ["hello"]
assert re.findall("he.+o", "hello planet") == ["hello"]

# This time we got no match, because there were not zero, not one, but two characters between "he" and the "o"
assert re.findall("he.?o", "hello planet") == []

# Zero occurrence
assert re.findall("he.?o", "heo planet") == ["heo"]

# One occurrence
assert re.findall("he.?o", "hemo planet") == ["hemo"]

# ----------------------------- {} : Exactly the specified number of occurrences ---------------------------
assert re.findall("he.{2}o", "hello planet") == ["hello"]

# ------------------------------- | Either or -----------------------------
# Check if the string contains either "falls" or "stays":
assert re.findall("falls|stays", "The rain in Spain falls mainly in the plain!") == ['falls']
