"""
Types of exception : https://docs.python.org/3/library/exceptions.html
"""

class TestFirst:

    def first_method(self):
        try:
            a = 10
            b = 0
            print(a / b)
        except ZeroDivisionError:
            print("Division by zero is not valid")
        except Exception as error:
            print("Error occurred : ", error)
        finally:
            print("This is finally block")


ob1 = TestFirst()
ob1.first_method()
