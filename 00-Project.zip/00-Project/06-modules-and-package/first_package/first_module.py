print("\nTop print - This is first-module")


def first_method():
    print("This is first method")


if __name__ == "__main__":
    print("This is called from first-module directly")
else:
    print(f"Else - This is called from another file ")
