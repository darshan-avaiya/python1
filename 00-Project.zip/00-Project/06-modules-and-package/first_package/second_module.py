print("\nTop print - This is second-module")


def second_method():
    print("This is second method")


if __name__ == "__main__":
    print("This is called from second-module directly")
else:
    print(f"This is called from another file")
