print("\nTop print - This is sixth-module")


def sixth_method():
    print("This is sixth method")


if __name__ == "__main__":
    print("This is called from sixth-module directly")
else:
    print(f"This is called from another file ")
