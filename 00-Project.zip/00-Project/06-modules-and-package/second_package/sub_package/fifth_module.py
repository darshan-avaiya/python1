print("\nTop print - This is fifth-module")


def fifth_method():
    print("This is fifth method")


if __name__ == "__main__":
    print("This is called from fifth-module directly")
else:
    print(f"This is called from another file ")
