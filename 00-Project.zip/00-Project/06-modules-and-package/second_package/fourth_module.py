print("\nTop print - This is fourth-module")


def fourth_method():
    print("This is fourth method")


if __name__ == "__main__":
    print("This is called from fourth-module directly")
else:
    print(f"This is called from another file ")
