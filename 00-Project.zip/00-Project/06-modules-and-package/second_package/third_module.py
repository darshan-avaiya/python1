print("\nTop print - This is third-module")


def third_method():
    print("This is third method")


if __name__ == "__main__":
    print("This is called from third-module directly")
else:
    print(f"This is called from another file ")
