from second_main_file import main_second_method
from first_package import first_module
from first_package import second_module
from second_package import third_module
from second_package import fourth_module
from second_package.sub_package import fifth_module
from second_package.sub_package import sixth_module

print("\nTop print - This is main-first-module")


def main_first_method():
    print("This is main-first method")


if __name__ == "__main__":
    print("This is called from main-first-module directly")
    main_second_method()
    first_module.first_method()
    second_module.second_method()
    third_module.third_method()
    fourth_module.fourth_method()
    fifth_module.fifth_method()
    sixth_module.sixth_method()

else:
    print(f"This is called from another file ")
