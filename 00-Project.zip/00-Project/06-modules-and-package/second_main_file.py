print("\nTop print - This is main-second-module")


def main_second_method():
    print("This is main-second method")


if __name__ == "__main__":
    print("This is called from main-second-module directly")
else:
    print(f"Else - This is called from another file")
