"""
Given an int n, return True if it is within 10 of 100 or 200.

near_hundred(93) → True
near_hundred(90) → True
near_hundred(89) → False
"""


def near_func(num):
    if abs(num - 100) <= 10 or abs(num - 200) <= 10:
        return True
    return False


assert near_func(89) == False
assert near_func(90) == True
assert near_func(93) == True

assert near_func(189) == False
assert near_func(190) == True
assert near_func(193) == True
