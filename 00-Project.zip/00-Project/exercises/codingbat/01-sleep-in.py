"""
The parameter weekday is True if it is a weekday, and the parameter vacation is True if we are on vacation.
We sleep in if it is not a weekday or we're on vacation. Return True if we sleep in.

sleep_in(False, False) → True
sleep_in(True, False) → False
sleep_in(False, True) → True
"""


def sleep_in(weekday, vacation):
    if weekday == False or vacation == True:
        return "I am on vacation"
    return "I am in office"


assert sleep_in(weekday=True, vacation=True) == "I am on vacation"
assert sleep_in(weekday=True, vacation=False) == "I am in office"
assert sleep_in(weekday=False, vacation=False) == "I am on vacation"
assert sleep_in(weekday=False, vacation=True) == "I am on vacation"
