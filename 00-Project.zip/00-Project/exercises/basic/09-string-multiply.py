"""
Given a string, return a string where for every character in the original there are three characters
"""


def myfunc(text):
    temp = ''
    for chr in text:
        temp = temp + chr * 3
    return temp


assert myfunc("Darshan") == "DDDaaarrrssshhhaaannn"
assert myfunc("aabc") == "aaaaaabbbccc"
