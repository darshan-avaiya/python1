"""
Given three integers between 1 and 11,
    1. if their sum is less than or equal to 21, return their sum.
    2. If their sum exceeds 21 and there's an eleven, reduce the total sum by 10.
    3. if the sum (even after adjustment) exceeds 21, return 'BUST'
"""


def check_sum(*args):
    total_sum = sum(args)

    if total_sum <= 21:
        return total_sum
    elif total_sum <= 31 and 11 in args:
        return total_sum - 10
    else:
        return "BUST"


assert check_sum(5, 6, 7) == 18
assert check_sum(8, 8, 8) == "BUST"
assert check_sum(10, 11, 4) == 15
assert check_sum(11, 11, 11) == "BUST"
