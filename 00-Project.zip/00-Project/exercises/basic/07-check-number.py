"""
Given an integer n, return True if n is within 10 of either 100 or 200

> It calculates the absolute difference between n and 100 using abs(n - 100) and checks if it is less than or equal to 10

"""


def check_number(n):
    if abs(n - 100) <= 10 or abs(n - 200) <= 10:
        return True
    return False


assert check_number(80) == False

assert check_number(90) == True
assert check_number(100) == True
assert check_number(110) == True

assert check_number(190) == True
assert check_number(200) == True
assert check_number(210) == True

assert check_number(211) == False
