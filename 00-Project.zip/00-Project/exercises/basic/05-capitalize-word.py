"""
Write a function that capitalizes the first and fourth letters of a name
"""


def capitalize_word(name):
    if len(name) >= 4:
        name = name[0].upper() + name[1:3] + name[3].upper() + name[4:]
    return name


# Test cases
assert capitalize_word("abcdefg") == "AbcDefg"
assert capitalize_word("Abcdefg") == "AbcDefg"
assert capitalize_word("darshan") == "DarShan"
assert capitalize_word("dar") == "dar"
assert capitalize_word("dars") == "DarS"
