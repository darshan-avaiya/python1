"""
Given a sentence, return a sentence with the words reversed
"""


def myfunc(statement):
    temp = statement.split()
    # return ' '.join(temp[::-1])
    temp.reverse()
    return ' '.join(temp)


assert myfunc("I am Darshan") == "Darshan am I"
