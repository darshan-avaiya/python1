import random


def guess_ball_position(my_list):
    while True:
        position = input("Enter ball position: ").strip()
        if position.isdigit() and int(position) in range(len(my_list)):
            return int(position)
        else:
            print("Invalid input. Please enter a valid position.")


def shuffle_list(my_list):
    random.shuffle(my_list)
    return my_list


def play_game(my_list):
    while True:
        position = guess_ball_position(my_list)
        shuffled_list = shuffle_list(my_list)
        if shuffled_list[position] == 'O':
            print("You won the game")
        else:
            print("You lost the game")
        print(shuffled_list)
        # play again
        while True:
            user_input = input("Do you want to play again? (yes/no): ").lower()
            if user_input == 'yes':
                break
            elif user_input == 'no':
                # return
                exit(0)
            else:
                print("\nPlease provide valid input\n")


list1 = ['', 'O', '']
play_game(list1)
