"""
Write a function that returns the lesser of two given numbers if both numbers are even, but returns the greater if one or both numbers are odd
    1. Both even - return lesser
    2. One of odd - return greater
"""


def get_smallest_even(num1, num2):
    """Returns the smallest even number between num1 and num2."""
    return min(num1, num2)


def get_largest(num1, num2):
    """Returns the largest number between num1 and num2."""
    return max(num1, num2)


def func(num1, num2):
    """Returns the smallest even number if both num1 and num2 are even, otherwise returns the largest number."""
    if num1 % 2 == 0 and num2 % 2 == 0:
        return get_smallest_even(num1, num2)
    else:
        return get_largest(num1, num2)


assert func(10, 20) == 10
assert func(11, 20) == 20
assert func(11, 21) == 21
assert func(10, 21) == 21
