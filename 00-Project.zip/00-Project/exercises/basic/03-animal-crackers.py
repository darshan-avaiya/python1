"""
Write a function takes a two-word string and returns True if both words begin with same letter
"""


def myfunc(word):
    first, second, *other_part = word.split()
    if first[0] == second[0]:
        return True
    else:
        return False


assert myfunc("Diu Dandi") == True
assert myfunc("Test Method") == False
