"""
Given a list of ints, return True if the array contains a 3 next to a 3 somewhere.
"""


def check_number(list1):
    for index in range(len(list1) - 1):
        if list1[index] == 3 and list1[index + 1] == 3:
            return True
    return False


assert check_number([1, 2, 3, 3]) == True
assert check_number([1, 2, 3, 4, 5, 3]) == False
assert check_number([1, 3, 1, 3, 0, 3, 3]) == True

