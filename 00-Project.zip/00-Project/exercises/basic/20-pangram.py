"""
Write a Python function to check whether a string is pangram or not. (Assume the string passed in does not have any punctuation)

Note : Pangrams are words or sentences containing every letter of the alphabet at least once.
For example : "The quick brown fox jumps over the lazy dog"

Hint: You may want to use .replace() method to get rid of spaces.
"""

import string


def is_pangram(str1, alphabets=string.ascii_lowercase):
    str1 = list(set(str1.lower().replace(" ", "")))
    str1.sort()
    return str1 == list(alphabets)


assert is_pangram("The quick brown fox jumps over the lazy dog") == True
assert is_pangram("abcdefghijklmnopqrstuvwxyz") == True
assert is_pangram("abcdefghijklm") == False
