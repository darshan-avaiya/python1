"""
SPY GAME: Write a function that takes in a list of integers and returns True if it contains 007 in order
 spy_game([1,2,4,0,0,7,5]) --> True
 spy_game([1,0,2,4,0,5,7]) --> True
 spy_game([1,7,2,0,4,5,0]) --> False
"""


def spy_game(list1):
    order = [0, 0, 7]
    index = 0

    for obj in list1:
        if obj == order[index]:
            index = index + 1
            if index == len(order):
                return True
    return False


assert spy_game([1, 2, 4, 0, 0, 7, 5]) == True
assert spy_game([1, 0, 2, 4, 0, 5, 7]) == True
assert spy_game([1, 7, 2, 0, 4, 5, 0]) == False
