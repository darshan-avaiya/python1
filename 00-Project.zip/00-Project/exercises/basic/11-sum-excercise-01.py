"""
SUMMER OF '69:
Return the sum of the numbers in the array,
except ignore sections of numbers starting with a 6 and extending to the next 9 (every 6 will be followed by at least one 9).
Return 0 for no numbers.
    1. summer_69([1, 3, 5]) --> 9
    2. summer_69([4, 5, 6, 7, 8, 9]) --> 9
    3. summer_69([2, 1, 6, 9, 11]) --> 14
"""


def summer_69(list1):
    temp = 0
    skip_mode = False
    for obj in list1:
        if obj == 6:
            skip_mode = True
        elif obj == 9:
            skip_mode = False
        elif skip_mode == False:
            temp = temp + obj
    return temp


assert summer_69([1, 3, 5]) == 9
assert summer_69([4, 5, 6, 7, 8, 9]) == 9
assert summer_69([2, 1, 6, 9, 11]) == 14
