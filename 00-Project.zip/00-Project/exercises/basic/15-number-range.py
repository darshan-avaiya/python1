"""
Write a function that checks whether a number is in a given range (inclusive of high and low)
"""


def ran_check(num, low, high):
    return low <= num <= high


assert ran_check(5, 3, 10) == True
assert ran_check(5, 6, 10) == False
