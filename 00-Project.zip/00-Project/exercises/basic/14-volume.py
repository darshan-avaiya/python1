"""
Write a function that computes the volume of a sphere given its radius

Formula = 4/3 * pi * r^3
"""

import math


def vol(rad):
    return (4 / 3) * math.pi * (rad ** 3)


assert vol(2) == 33.510321638291124
