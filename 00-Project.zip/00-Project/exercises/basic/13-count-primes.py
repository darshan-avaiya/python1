"""
COUNT PRIMES: Write a function that returns the number of prime numbers that exist up to and including a given number

count_primes(100) --> 25
"""


def count_primes(number):
    total = 0
    for n in range(number + 1):
        count = 0
        for i in range(1, n + 1):
            if n % i == 0:
                count = count + 1
        if count == 2:
            total = total + 1
    return total


assert count_primes(100) == 25
