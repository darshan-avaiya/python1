"""
Given two integers, return True if the sum of the integers is 20 or if one of the integers is 20. If not, return False
"""


def myfunc(num1, num2):
    if num1 + num2 == 20 or num1 == 20 or num2 == 20:
        return True
    return False


assert myfunc(10, 20) == True
assert myfunc(20, 10) == True
assert myfunc(15, 5) == True
assert myfunc(20, 0) == True
assert myfunc(10, 5) == False
