"""
The word "polymorphism" means "many forms" -

Multiple classes having same method name that can be executed on many objects or classes.
"""


class First:
    def __init__(self, name, roll):
        self.name = name
        self.roll = roll

    def display(self):
        print(f"Name : {self.name}, Roll : {self.roll}")


class Second:
    def __init__(self, name, roll):
        self.name = name
        self.roll = roll

    def display(self):
        print(f"Name : {self.name}, Roll : {self.roll}")


class Third:
    def __init__(self, name, roll):
        self.name = name
        self.roll = roll

    def display(self):
        print(f"Name : {self.name}, Roll : {self.roll}")


ob1 = First("Darshan", 11)
ob2 = Second("Dipak", 12)
ob3 = Third("Kushalyogi_swami", 13)

for ob in [ob1, ob2, ob3]:
    ob.display()
