"""
1. What is abstract method ?
    -> An abstract method is a method that has a declaration but does not have an implementation.
    -> An abstract class can be considered a blueprint for other classes.
    -> It allows you to create a set of methods that must be created within any child classes built from the abstract class.
2. What is abstract class ?
    -> A class that contains one or more abstract methods is called an abstract class.
"""

class parent:

    # abstract method
    def display(self, name, roll):
        pass


class child(parent):

    def display(self, name, roll):
        print("This is display method")


ob1 = child()
ob1.display("Darshan", 11)
