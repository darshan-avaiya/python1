class TestBase:

    def __init__(self, name, roll):
        print("This is Base class method")
        self.name = name
        self.roll = roll

    def display(self):
        print("This is display method from Base class")
        print(f"My name is {self.name} and my roll is {self.roll}")

    def show(self):
        print("This is Show method from Base class")


class TestChild(TestBase):

    def __init__(self, name, roll):
        TestBase.__init__(self, name, roll)
        print("This is Child class method")

    def show(self):
        print("This is show method from child class")
        print(f"My name is {self.name} and my roll is {self.roll}")


ob1 = TestChild("darshan", 11)
ob1.display()
ob1.show()
