class Test:

    def __init__(self, name, roll):
        self.name = name
        self.roll = roll

    def __str__(self):
        return f"My name is {self.name} and roll number is {self.roll}"

    def __len__(self):
        return len(self.name)

    def __del__(self):
        print("Object is deleted")


t1 = Test("Darshan", 11)

print(t1)
print(len(t1))
del t1
