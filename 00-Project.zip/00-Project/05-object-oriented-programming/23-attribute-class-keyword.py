"""
1. What is diff. between functions and method ?
    - Methods are defined inside the class while functions are defined outside the class
    - Methods work with object
2. Class object attribute vs User defined attribute ?
    - Class object attribute are defined inside the class but outside the method
    - User defined attribute are defined inside the method
3. Attribute vs parameter ?
    - We assign parameter value to attribute inside the method-- [ self.name (attribute) = name (parameter) ]
"""


class TestFirst:
    # class object attribute - No need to put self keyword
    teacher = "Shiva"

    def __init__(self, roll, name):
        # user defined attributes
        # self.name = name [attribute = parameter]
        self.name = name
        self.roll = roll

    def display(self):
        print(f"My name is {self.name} and roll number is {self.roll} and teacher is {self.teacher}/{TestFirst.teacher}")


ob1 = TestFirst(11, "Darshan")
assert ob1.roll == 11
assert ob1.name == "Darshan"
ob1.display()

ob2 = TestFirst(12, "Test")
assert ob2.roll == 12
assert ob2.name == "Test"
ob2.display()

assert ob1.teacher == "Shiva"
assert ob2.teacher == "Shiva"
