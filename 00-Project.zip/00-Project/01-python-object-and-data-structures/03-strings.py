# String can be defined in single and double quotes
single_quotes = 'Darshan'
double_quotes = "I don't like tea"

# Last character does not include in string slicing
str1 = "My name is Darshan"
assert str1 == "My name is Darshan"
assert str1[3:14] == "name is Dar"
assert str1[:14] == "My name is Dar"
assert str1[2:] == " name is Darshan"
assert str1[:] == "My name is Darshan"
assert str1[:-1] == "My name is Darsha"

# Reverse string
assert str1[::-1] == "nahsraD si eman yM"

# Jump in string
assert str1[::2] == "M aei asa"

# Functions in string
assert str1.split() == ["My", "name", "is", "Darshan"]
assert str1.split(' ') == ["My", "name", "is", "Darshan"]
assert str1.split('a') == ["My n", "me is D", "rsh", "n"]
assert str1.upper() == "MY NAME IS DARSHAN"
assert str1.lower() == "my name is darshan"
assert str1.__contains__("Darshan") == True
assert ("Darshan" in str1) == True
assert str1.find("Darshan") != -1
assert " My name is Darshan ".strip() == "My name is Darshan"
assert " My name is Darshan ".rstrip() == " My name is Darshan"
assert " My name is Darshan ".lstrip() == "My name is Darshan "

# String formatting using format() and f-string method
str2 = "My name is {}. I am from {}"
assert str2.format("Darshan", "Surat") == "My name is Darshan. I am from Surat"

str3 = "My name is {1}. I am from {0}"
assert str3.format("Surat", "Darshan") == "My name is Darshan. I am from Surat"

str4 = "My name is {name}. I am from {city}"
assert str4.format(city="Surat", name="Darshan") == "My name is Darshan. I am from Surat"

name = "Darshan"
city = "Surat"
str5 = f"My name is {name}. I am from {city}"
assert str5 == "My name is Darshan. I am from Surat"


# Float Formatting in Python
temp = 104.6987451235462
assert "Temperature is {result:1.3f} F".format(result=temp) == "Temperature is 104.699 F"
assert "Temperature is {result:1.7f} F".format(result=temp) == "Temperature is 104.6987451 F"

# 11 (numbers including dot) - it will occupy 11 place
assert "Temperature is {result:11.7f} F".format(result=temp) == "Temperature is 104.6987451 F"

# 12 (11 numbers including dot) + 1 space - It will occupy 12 place
assert "Temperature is {result:12.7f} F".format(result=temp) == "Temperature is  104.6987451 F"
assert "Temperature is {result:10.3f} F".format(result=temp) == "Temperature is    104.699 F"
