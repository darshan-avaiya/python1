"""
File modes
    1. 'r'  [ Only reading file - it will not allow to write file - once file is read then curser will go to end of the file]
    2. 'w'  [ Only writing file - it will not allow to read file - create new file if not exist - overwrite if exist ]
    3. 'a'  [ Append file - it will not allow to read file - create new file if not exist - append if exist ]
    4. 'r+' [ Read and write file - throw an error if file not exist - wipe-out only few content equal to length of written text if exist ]
    5. 'w+' [ Read and write file - create new file if file not exist - wipe-out all content if exist ]
"""

file = open('../resources/02-simple-write-file.txt', 'w')
file.write('This is first line')
file.write('\nThis is second line')
file.close()

file = open('../resources/02-simple-write-file.txt', 'a')
file.write('\nThis is third line')
file.close()

file = open('../resources/02-simple-write-file.txt', 'r')
assert file.read() == "This is first line\nThis is second line\nThis is third line"
assert file.read() == ""
file.seek(0)
assert file.read() == "This is first line\nThis is second line\nThis is third line"
file.seek(20)
assert file.read() == "This is second line\nThis is third line"
file.close()

file = open('../resources/02-simple-write-file.txt', 'r+')
file.write('Read write - New line1')
file.write('\nRead write - New line2')
assert file.read() == "is third line"
assert file.read() == ""
file.seek(0)
assert file.read() == "Read write - New line1\nRead write - New line2is third line"
assert file.read() == ""
file.close()

file = open('../resources/02-simple-write-file.txt', 'w+')
file.write('Read write - temp line1')
file.write('\nRead write - temp line2')
assert file.read() == ""
file.seek(0)
assert file.read() == "Read write - temp line1\nRead write - temp line2"
assert file.read() == ""
file.close()
