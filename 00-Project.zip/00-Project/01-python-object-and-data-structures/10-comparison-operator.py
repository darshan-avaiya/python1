assert (1 == 1) == True
assert (1 != 1) == False
assert (1 < 5) == True
assert (1 > 5) == False
assert (2 <= 2) == True
assert (2 <= 5) == True
assert (1< 5 < 8) == True
assert (1< 5 > 8) == False
