# key value pair
dict1 = {"name": "Darshan", "roll": 15, "sub": {"Maths": 90, "English": 80, "Physics": 85}}
assert dict1["name"] == "Darshan"
assert dict1["roll"] == 15
assert dict1["sub"] == {"Maths": 90, "English": 80, "Physics": 85}
assert dict1["sub"]["Maths"] == 90

dict1["name"] = "Test"
assert dict1 == {"name": "Test", "roll": 15, "sub": {"Maths": 90, "English": 80, "Physics": 85}}

assert list(dict1.keys()) == ["name", "roll", "sub"]
assert list(dict1.values()) == ["Test", 15, {"Maths": 90, "English": 80, "Physics": 85}]
assert list(dict1.items()) == [('name', 'Test'), ('roll', 15), ('sub', {'Maths': 90, 'English': 80, 'Physics': 85})]
