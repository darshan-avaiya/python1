"""

Rules for variable names
  1. Variable name should not be started with number
  2. Spaces should not be allowed in variable name
  3. Special Characters should not be allowed (example :'",<>/?|\()!@#$%^&*~-+)
  4. Only underscore _ is allowed
  5. You cannot use built-in keyword like str, int, list as variable name
  6. Python supports Dynamic data typing,
        >> If you have an integer type variable then later in the code you can assign a different data type (ie. string) to same variable

"""
