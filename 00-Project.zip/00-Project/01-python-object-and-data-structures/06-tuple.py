tuple1 = (1, 2, 3, 3)
assert tuple1[0] == 1
assert tuple1[1] == 2
assert tuple1[-1] == 3
assert tuple1.count(3) == 2
assert tuple1.index(2) == 1

# unpacking tuple from dictionary
# get maximum amount item

list1 = [("Apple", 50), ("Banana", 10), ("Orange", 90)]


def get_max_value_item(my_list):
    temp_max_value = 0
    temp_item = ''
    for (key, value) in my_list:
        if value > temp_max_value:
            temp_max_value = value
            temp_item = key
    return (temp_item, temp_max_value)


result = get_max_value_item(list1)
assert result == ("Orange", 90)

item, value = get_max_value_item(list1)
assert item == "Orange"
assert value == 90
