result = 1 > 5
assert result == False

result = 1 < 5
assert result == True
