# List slicing same as string, List is mutable and string is immutable
items = [1, 2, 44.65, "Darshan", [10, 20, 30], (40, 50, 60), {"name": "Darshan", "roll": "59"}, "one", "two"]

assert len(items) == 9
assert items[2] == 44.65
assert items[2:6] == [44.65, "Darshan", [10, 20, 30], (40, 50, 60)]

# Concatenation, append, remove, pop
list1 = [10, 20, 30]
list2 = ["one", "two", "three"]
sum_list = list1 + list2
assert sum_list == [10, 20, 30, "one", "two", "three"]

sum_list.append("four")
assert sum_list == [10, 20, 30, "one", "two", "three", "four"]

sum_list.remove("one")
assert sum_list == [10, 20, 30, "two", "three", "four"]

sum_list.pop()
assert sum_list == [10, 20, 30, "two", "three"]

sum_list.pop(0)
assert sum_list == [20, 30, "two", "three"]

sum_list.pop(-1)
assert sum_list == [20, 30, "two"]

# sort list
list1 = [50, 10, 30, 20, 40]
list1.sort()
assert list1 == [10, 20, 30, 40, 50]

list2 = ['d', 'a', 'c', 'b']
list2.sort()
assert list2 == ['a', 'b', 'c', 'd']
assert list2.count('a') == 1

# LIST Comprehension
list1 = []
for letter in "Happy":
    list1.append(letter)
assert list1 == ['H', 'a', 'p', 'p', 'y']
assert list("Happy") == ['H', 'a', 'p', 'p', 'y']

assert [x for x in "Happy"] == ['H', 'a', 'p', 'p', 'y']
assert [x for x in range(3, 10)] == [3, 4, 5, 6, 7, 8, 9]
assert [x ** 2 for x in range(3, 10)] == [9, 16, 25, 36, 49, 64, 81]
assert list(range(3, 10)) == [3, 4, 5, 6, 7, 8, 9]
assert [x for x in range(3, 10) if x % 2 == 0] == [4, 6, 8]
assert [x if x % 2 == 0 else "Odd" for x in range(3, 10)] == ["Odd", 4, "Odd", 6, "Odd", 8, "Odd"]

cel = [10, 20, 30, 40]
assert [(9 / 5 * temp + 32) for temp in cel] == [50.0, 68.0, 86.0, 104.0]
