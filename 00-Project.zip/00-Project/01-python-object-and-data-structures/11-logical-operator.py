"""
AND - True only if both statement are True
OR  - True if one of the expression is True
NOT - True if expression is False
"""

assert (2 < 5 and len("Darshan") == 7) == True
assert (2 > 5 and len("Darshan") == 7) == False

assert (2 < 5 or len("Darshan") == 7) == True
assert (2 > 5 or len("Darshan") == 7) == True

assert not(5 == 5) == False
