# Basic-Data-Types

# Square braces [] - list
# Curly braces {} - dictionary
# Parentheses () - tuple

# 1. Integers (int)
intA = 5
intB = 10
print("Type of variable", type(intA))

# 2. Floating point (float)
floatA = 2.5
floatB = 123.0

# 3. Strings (str) >> Ordered sequence of characters
strA = "hello"
strB = 'Sammy'
strC = "2000"
strD = "楽しい"

# Data Structures types

# 4. Lists (list) >> Collection of ordered mutable sequence of objects
listA = [10, "hello", 200.3]

# 5. Dictionaries (dict) >> Collection of unordered Key and Value pairs
dictA = {"mykey": "value", "name": "Frankie"}
assert dictA["mykey"] == "value"
assert dictA["name"] == "Frankie"

# 6. Tuples (tup) >> Collection of ordered immutable sequence of objects
tupleA = (10, "hello", 200.3)
assert tupleA[0] == 10
assert tupleA[1] == "hello"

# 7. Sets (set) >> Collection of unordered unique objects
setA = {"a", "b", 1}
print(setA)

# 8. Booleans (bool) >> Logical value indicating True or False
isBool = (5 == 5)
assert isBool == True
