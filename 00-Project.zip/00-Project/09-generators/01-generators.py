"""
Generators functions allow us to generate the sequence of values over a time...and send back a value and then
later resume to pick up where it left off....

Instead of return keyword we are using yield keyword...

When generator function is compiled they become an object that supports an iteration protocol...

Generator is more memory efficient than a list....
"""


# --------------------------------------------------

def first_method(upper_limit):
    list1 = []
    for i in range(upper_limit):
        list1.append(i ** 2)
    return list1


# iterate a list to get one by one value
for x in first_method(10):
    print(x, end=", ")
print()


# --------------------------------------------------

def second_method(upper_limit):
    for i in range(upper_limit):
        yield (i ** 2)


for x in second_method(10):
    print(x, end=", ")

# --------------------------------------------------
